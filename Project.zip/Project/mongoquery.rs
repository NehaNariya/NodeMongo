//show all database
show dbs

//create database
use rku

//all the collections are show
show collections

//data show
db.rku.find()

//data show in formeting
db.rku.find().pretty()

//create collection
db.createCollection("rku")

//insert collection
db.rku.insert({name:"jay",branch:"mca",age:21})

db.rku.insertMany(
    [
       {name:"raj",sem:2,branch:"MCA",grade:"A",mobile:9988776655,address:{building_name:"C",street:3,land_mark:"rajkot",pincode:360020},"city":"Rajkot"},
       {name:"magan",sem:2,branch:"MCA",grade:"A",mobile:8866442233,address:{building_name:"C",street:3,land_mark:"rajkot",pincode:360020},"city":"baroda"},
       {name:"ram",sem:2,branch:"MCA",grade:"B",mobile:8980232342,address:{building_name:"A",street:3,land_mark:"rajkot",pincode:360020},"city":"keshod"},
       {name:"madhav",sem:2,branch:"MCA",grade:"B+",mobile:8980223344,address: {building_name:"B",street:3,land_mark:"rajkot",pincode:360020},"city":"Rajkot"},
       {name:"chagan",sem:2,branch:"MCA",grade:"C",mobile:8866443322,address:{building_name:"A",street:3,land_mark:"rajkot",pincode:360020},"city":"surat"}
    
    ]    
)

//update data aa query thi khali ak j update thase
db.stud.update({name:raj},{$set:{name:dev}})

//vadhare data update karva mate
db.stud.updateMany({name:raj},{$set:{name:dev}})

//upsert aa no use data hase to update thase and nai hoy to insert thai jase ok
db.stud.update({name:raj},{$set:{name:dev}},{upsert:true})

//delete 
db.rku.deleteOne({name:"raj"})

db.rku.deleteMany({})

db.rku.drop()

//output with status equals "B"
db.rku.find({branch:"mca"}).pretty()

//output with name field only
db.rku.find({branch:"MCA"},{name:1}).pretty()

//output without id aetle k id na aavu joye
db.rku.find({branch:"MCA"},{name:1,_id:0}).pretty()

//find filter to "active:true" and get only the first filed with "active:true" values
db.rku.find({Active:true}).limit(1)

//set the filter to “active :ture” and get only the first field with “active : true” value by skipping the 1st  field
db.rku.find({Active:true}).skip(1).limit(1)

//Retrieves all documents from the inventory collection where status equals either "A" or "D".
db.rku.find({branch:MCA,grade:"A"})

//Retrieve documents in the inventory collection where the status equals "A" and qty is less than ($lt (Links to an external site.)Links to an external site.) 30
db.rku.find({$or:[{branch:"MCA"},{grade:{$lt:B}}]})

//rename collection
db.stud.renameCollection("Mark")

//m thi name chalu thatu hoy to
db.stud.find({name:{$regex:/^m/}})

//chhele m aavtu hoy to
db.stud.find({name:{$regex:/m$/}})

//vachhe game tya lin aavtu hoy to
db.stud.find({name:{$regex:/lin/}})

//line m thi start thati hoy to
db.stud.find({name:{$regex:/m/,$option:"si"}})

//json data puchay to tene import karva mate
mongoimport --db databasename --collection res --file D:\restaurants.json

--------------

--------------------------
//node mate have

//aa code GETAPI mate no chhe
//model folder ni andar movies.js name ni file no code

var mongoose = require('mongoose');

var studSchema = mongoose.Schema({
    name:String,
    city:String,
    pin:String,
    branch:String
})

module.exports = mongoose.model("studs",studSchema);
------------------
//aa index.js file no code chhe

// var mongoose = require('mongoose');
// var express = require('express');
// var bodyParser = require('body-parser');
// var route = require('./route');

// mongoose.connect("mongodb+srv://devang:devang7492@cluster0.hchkg.mongodb.net/Student?retryWrites=true&w=majority").then(()=>{
// console.log("conncted");
// app = express();
// app.use(express.json());
// app.use(bodyParser.urlencoded({extended:false}))
// app.use('/api',route)

// app.listen(3004,()=>{
//     console.log("Server Running")
// })
// }).catch((err)=>{
//     console.log(err);
// })
-----------------
//aa code route.js mate no chhe

var express = require('express');
const movie = require('./model/movie');
var stud = require('./model/movie')
var route = express.Router();


route.get('/stud',async(req,res)=>{
  var imovie = await stud.find();
  res.send(imovie);

})
module.exports = route;

---------------------

---------------
//aa code POSTAPI mate no chhe

//model folder ni andar movies.js name ni file no code

var mongoose = require('mongoose');

var studSchema = mongoose.Schema({
    name:String,
    rating:Number
})

module.exports = mongoose.model("movie",studSchema);
---------------------

//index.js mate no

// var mongoose = require('mongoose');
// var express = require('express');
// var bodyParser = require('body-parser');
// var route = require('./route');

// mongoose.connect("mongodb+srv://devang:devang7492@cluster0.hchkg.mongodb.net/Student?retryWrites=true&w=majority").then(()=>{
// console.log("conncted");
// app = express();
// app.use(express.json());
// app.use(bodyParser.urlencoded({extended:false}))
// app.use('/api',route)

// app.listen(3004,()=>{
//     console.log("Server Running")
// })
// }).catch((err)=>{
//     console.log(err);
// })
---------------------

//route.js mate no

var express = require('express');
var movie = require('./model/movie')
var route = express.Router();


route.get('/movie',async(req,res)=>{
  var imovie = await movie.find();
  res.send(imovie);

})
route.post("/movie",async(req,res)=>{
  const imovie = new movie({
    name:req.body.name,
    rating:req.body.rating
  })
  console.log(imovie)
  await imovie.save((err,msg)=>{
    if(err){
      res.status(500).json({
          "error":err
      })
  }
  else{
      res.status(200).json({
          "My-message":msg
      })
  }
  })
})
module.exports = route;

-----------------
//KOi JAT NA SAVAL KARVA NAI AME AVDI MENAT KARI  NE TAMARA SATU BANAVI CHHE OKKKKKK PLEASEEEEEEE


////Hands on with Querying using Regex Expression

// In order to perform following queries use a collection products with the
// following documents:
// { "_id" : 100, "sku" : "abc123", "description" : "Single line description." }
// { "_id" : 101, "sku" : "abc789", "description" : "First line\nSecond line" }
// { "_id" : 102, "sku" : "xyz456", "description" : "Many spaces before line" }
// { "_id" : 103, "sku" : "XYZ789", "description" : "Multiple\nline description" }

1. find the documents whose description starts with "M".
> db.product.find({description:{$regex:/^M/}})
{ "_id" : 102, "sku" : "xyz456", "description" : "Many spaces before line" }
{ "_id" : 103, "sku" : "XYZ789", "description" : "Multiple\nline description" }

2. find the documents whose description end with "n"
> db.product.find({description:{$regex:/n$/}})
{ "_id" : 103, "sku" : "XYZ789", "description" : "Multiple\nline description" }

3. find the documents whose description contains "line" word"
> db.product.find({description:{$regex:/line/}})
{ "_id" : 100, "sku" : "abc123", "description" : "Single line description." }
{ "_id" : 101, "sku" : "abc789", "description" : "First line\nSecond line" }
{ "_id" : 102, "sku" : "xyz456", "description" : "Many spaces before line" }
{ "_id" : 103, "sku" : "XYZ789", "description" : "Multiple\nline description" }

4. find the documents whose description contains second character "i".
> db.product.find({description:{$regex:/^.i/}})
{ "_id" : 100, "sku" : "abc123", "description" : "Single line description." }
{ "_id" : 101, "sku" : "abc789", "description" : "First line\nSecond line" }

5. find the documents where "sku" fields contains "xyz", ignore the case
sensitivity.
> db.product.find({sku:{$regex:/xyz/i}})
{ "_id" : 102, "sku" : "xyz456", "description" : "Many spaces before line" }
{ "_id" : 103, "sku" : "XYZ789", "description" : "Multiple\nline description" }

6. find the documents where any line from the description starts with 'S..
> db.product.find({description:{$regex:/^S/,$options:'si'}})
{ "_id" : 100, "sku" : "abc123", "description" : "Single line description." }


------------------------------


////Practice Basic CRUD

Perform the following tasks:

1. Create a database named "Students"
> use Students
switched to db Students
> db
Students

2. Create an empty collection named "studentData"
> db.createCollection("studentData")
{ "ok" : 1 }

3. Insert only one record with appropriate fields.
> db.studentData.insert({Name : "Neha",Sem : 2,Branch : "MCA",City : "Rajkot"})
WriteResult({ "nInserted" : 1 })

4. Try to insert 5 records together using single query
> db.studentData.insertMany([
... {Name : "Pooja",sem : 3,Branch : "BCA",City : "Surat"},
... {Name : "Kinjal",sem : 2,Branch : "MCA",City : "Mumbai"},
... {Name : "Prisha",sem : 1,Branch : "BBA",City : "Vadodara"},
... {Name : "Meera",sem : 2,Branch : "BCA",City : "Surat"},
... {Name : "Prisha",sem : 3,Branch : "MCA",City : "Rajkot"},
... ])
{
"acknowledged" : true,
"insertedIds" : [
ObjectId("6283cb665250ffcc90efc9f6"),
ObjectId("6283cb665250ffcc90efc9f7"),
ObjectId("6283cb665250ffcc90efc9f8"),
ObjectId("6283cb665250ffcc90efc9f9"),
ObjectId("6283cb665250ffcc90efc9fa")
]
}

5. Fetch all the documents in formatted manner.
> db.studentData.find().pretty()
{
"_id" : ObjectId("6283ca745250ffcc90efc9f5"),
"Name" : "Neha",
"Sem" : 2,
"Branch" : "MCA",
"City" : "Rajkot"
}
{
"_id" : ObjectId("6283cb665250ffcc90efc9f6"),
"Name" : "Pooja",
"sem" : 3,
"Branch" : "BCA",
"City" : "Surat"
}
{
"_id" : ObjectId("6283cb665250ffcc90efc9f7"),
"Name" : "Kinjal",
"sem" : 2,
"Branch" : "MCA",
"City" : "Mumbai"
}
{
"_id" : ObjectId("6283cb665250ffcc90efc9f8"),
"Name" : "Prisha",
"sem" : 1,
"Branch" : "BBA",
"City" : "Vadodara"
}
{
"_id" : ObjectId("6283cb665250ffcc90efc9f9"),
"Name" : "Meera",
"sem" : 2,
"Branch" : "BCA",
"City" : "Surat"
}
{
"_id" : ObjectId("6283cb665250ffcc90efc9fa"),
"Name" : "Prisha",
"sem" : 3,
"Branch" : "MCA",
"City" : "Rajkot"
}

6. Fetch the document based on the filter criteria.
> db.studentData.find({Name : "Pooja"},{Name : 1,_id : 0}).pretty()
{ "Name" : "Pooja" }

7. Delete one document from the "studentData".
> db.studentData.deleteOne({Name : "Prisha"})
{ "acknowledged" : true, "deletedCount" : 1 }
> db.studentData.find()
{ "_id" : ObjectId("6283ca745250ffcc90efc9f5"), "Name" : "Neha", "Sem" : 2, "Branch" :
"MCA", "City" : "Rajkot" }
{ "_id" : ObjectId("6283cb665250ffcc90efc9f6"), "Name" : "Pooja", "sem" : 3, "Branch" :
"BCA", "City" : "Surat" }
{ "_id" : ObjectId("6283cb665250ffcc90efc9f7"), "Name" : "Kinjal", "sem" : 2, "Branch" :
"MCA", "City" : "Mumbai" }
{ "_id" : ObjectId("6283cb665250ffcc90efc9f9"), "Name" : "Meera", "sem" : 2, "Branch" :
"BCA", "City" : "Surat" }
{ "_id" : ObjectId("6283cb665250ffcc90efc9fa"), "Name" : "Prisha", "sem" : 3, "Branch" :
"MCA", "City" : "Rajkot" }

8. Delete the documents based on the filter criteria.
> db.studentData.deleteOne({Name : "Meera"})
{ "acknowledged" : true, "deletedCount" : 1 }

> db.studentData.find()
{ "_id" : ObjectId("6283ca745250ffcc90efc9f5"), "Name" : "Neha", "Sem" : 2, "Branch" :
"MCA", "City" : "Rajkot" }
{ "_id" : ObjectId("6283cb665250ffcc90efc9f6"), "Name" : "Pooja", "sem" : 3, "Branch" :
"BCA", "City" : "Surat" }
{ "_id" : ObjectId("6283cb665250ffcc90efc9f7"), "Name" : "Kinjal", "sem" : 2, "Branch" :
"MCA", "City" : "Mumbai" }
{ "_id" : ObjectId("6283cb665250ffcc90efc9fa"), "Name" : "Prisha", "sem" : 3, "Branch" :
"MCA", "City" : "Rajkot" }


9. Delete all the documents from the "studentData: collection
> db.studentData.deleteMany({})
{ "acknowledged" : true, "deletedCount" : 4 }
> db.studentData.find()

10. Drop the collection.
> db.studentData.drop()
true
