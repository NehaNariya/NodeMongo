var person = {
    name:"abc";
    dept:"MCA";
}