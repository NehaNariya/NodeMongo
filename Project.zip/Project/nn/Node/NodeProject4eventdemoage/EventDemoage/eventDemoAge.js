var event = require('events');

var em = new event.EventEmitter();
var ch = new event.EventEmitter();

em.on("myEvent",(data)=>{
    console.log(data);
})

ch.on("checkage", (age) => {
    if(age >= 18) {
        console.log("Eigble");
    }
    else
    {
        console.log("Not Eligble");
    }
})

em.emit('myEvent',"This is my data");

ch.emit('checkage',30)

//output:node eventDemoage lakhvu
//This is my data
//Eigble