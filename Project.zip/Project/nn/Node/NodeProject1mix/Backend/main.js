// var http = require('http')
// var server =  http.createServer(function(req,res){
//     res.write("Hello World");
//     res.end();
// })
// server.listen(3000);

//or 1 & 2 mathi game te chale

// var http = require('http')
// http.createServer(function(req,res){
//     res.write("Hello World");
//     res.end();
// }).listen(3000);



// var http = require('http')
// http.createServer(function(req,res){
//     res.write("Hello World");
//     res.end();
// }).listen(3000,()=>{
//     console.log("Server Started");
// });

/////expressjs
// var express = require('express');
// var app = express();

// app.get("/",(req,res)=>{
//     res.sendFile(__dirname+"/index.html");
// });

// app.listen(3000,() => {
//     console.log("server started");
// });


/////request & responce
//install/npm install -g nodeman 

var http = require('http');

http.createServer((req,res)=>{
    if(req,url=="/"){
        res.write("This is a Students Page");
    }
    else if(req.url == "/admin"){
        res.write("This is an admin Page");
    }
    res.end();
}).listen(3000,()=>{
    console.log("Server Started");
})


