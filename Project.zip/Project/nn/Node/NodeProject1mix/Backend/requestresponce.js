/////request & responce
//install/npm install -g nodeman 

var http = require('http');

http.createServer((req,res)=>{
    if(req.url=="/"){
        res.write("This is a Students Page");
    }
    else if(req.url == "/admin"){
        res.write("This is an admin Page");
    }
    res.end();
}).listen(3000,()=>{
    console.log("Server Started");
})