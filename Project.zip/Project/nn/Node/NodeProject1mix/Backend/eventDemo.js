var event = require('events');

var em = new event.EventEmitter();

em.on("myEvent",(data)=>{
    console.log(data);
})

em.emit('myEvent',"This is my data");