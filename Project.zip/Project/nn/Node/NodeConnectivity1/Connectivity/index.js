var mongoose = require('mongoose');
var express = require('express');
var bodyParser =  require('body-parser');

mongoose.connect("mongodb+srv://neha:neha882000@cluster0.xtwk6fo.mongodb.net/?retryWrites=true&w=majority").then(() => {
    console.log("DB Connected");

    app = express();
    app.listen(3000,()=>{
        console.log("Server started at 3000");
    })
}).catch((err)=>{
    console.log(err);
})

//output:
//DB Connected
//Server started at 3000