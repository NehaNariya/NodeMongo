import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {

  constructor() { }
  result=[" Deep-6354272800","Jaydeep-9909750103","Nick-9327539037"]

  ngOnInit(): void {
  }

}
