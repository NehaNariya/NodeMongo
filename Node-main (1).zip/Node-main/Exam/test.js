var test = "Hello"

var sum = (a,b)=>{
    return a+b
}

module.exports = {test,sum}
// module.exports = sum