var file = require('./test')

console.log(file.test)
console.log(file.sum(10,30))